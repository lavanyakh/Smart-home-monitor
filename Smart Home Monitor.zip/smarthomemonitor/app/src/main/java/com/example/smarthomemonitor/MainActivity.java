package com.example.smarthomemonitor;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import org.eclipse.paho.android.service.MqttAndroidClient;
import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.MqttClient;

import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    private TextView tempTextView, humidityTextView, lightTextView;
    protected final String serverUri = "tcp://broker.hivemq.com:1883";
    private final String clientId = MqttClient.generateClientId();
    private final String[] topics = {"home/temperature", "home/humidity", "home/light"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tempTextView = findViewById(R.id.tempTextView);
        humidityTextView = findViewById(R.id.humidityTextView);
        lightTextView = findViewById(R.id.lightTextView);

        setupMqttClient();
    }

    private void setupMqttClient() {
        MqttAndroidClient client = new MqttAndroidClient(getApplicationContext(), serverUri, clientId);

        try {
            MqttConnectOptions options = new MqttConnectOptions();
            options.setCleanSession(true);
            client.connect(options);

            client.setCallback(new MqttCallback() {
                @Override
                public void connectionLost(Throwable cause) {
                }

                @Override
                public void messageArrived(String topic, MqttMessage message) throws Exception {
                    String payload = new String(message.getPayload());
                    String displayText = String.format(Locale.getDefault(), "%.2f", Float.parseFloat(payload));
                    long timestamp = System.currentTimeMillis();
                    saveToLocalFile(topic, payload, timestamp);

                    if (topic.equals("home/temperature")) {
                        tempTextView.setText("Temperature: " + displayText + "°C");
                    } else if (topic.equals("home/humidity")) {
                        humidityTextView.setText("Humidity: " + displayText + "%");
                    } else if (topic.equals("home/light")) {
                        lightTextView.setText("Light Level: " + displayText + " lx");
                    }
                }

                @Override
                public void deliveryComplete(IMqttDeliveryToken token) {
                }
            });

            for (String topic : topics) {
                client.subscribe(topic, 0);
            }
        } catch (MqttException e) {
            e.printStackTrace();
        }
    }

    private void saveToLocalFile(String topic, String payload, long timestamp) {
        String fileName = "sensor_data.txt";
        String data = String.format(Locale.getDefault(), "%d,%s,%s\n", timestamp, topic, payload);

        try {
            FileOutputStream fos = openFileOutput(fileName, MODE_APPEND);
            OutputStreamWriter osw = new OutputStreamWriter(fos);
            osw.write(data);
            osw.close();
            fos.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
